package com.cucumber.commonServices;

import com.cucumber.commoncontrols.CommonConstants;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Objects;

public class ExcelServices {



//Read data from excel file and converts from numeric to string
    public XSSFSheet getExcelSheetTabData(String excelName, String sheetName) throws IOException {
        try {
            File src = new File("D:\\Test.xlsx");
            FileInputStream fis = new FileInputStream(src);
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            XSSFSheet sheet = workbook.getSheet(sheetName);
            int lastColNum = sheet.getRow(0).getLastCellNum();
            DataFormatter dataFormatter = new DataFormatter();
            for (Row nextRow : sheet) {
                for (int colNum = 1; colNum < lastColNum; colNum++) {
                    Cell cell = nextRow.getCell(colNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    if (Objects.requireNonNull(cell.getCellType()) == CellType.BLANK) {
                        cell.setCellValue("");
                    } else if(Objects.requireNonNull(cell.getCellType()) == CellType.NUMERIC) {
                        String numericAsString = dataFormatter.formatCellValue(cell);
                        cell.setCellValue(numericAsString);
                    }
                }
            }
            workbook.close();
            fis.close();
            return sheet;
        } catch (IOException ex) {
            return null;
        }
    }

    //rename
    public String renameListExcelFile(String source, String fileName) {
        File file = new File(source);
        File file1 = new File(fileName);
        boolean flag = file.renameTo(file1);
        if (flag) {
            System.out.println("File Successfully Rename");
        } else {
            System.out.println("Rename Operation Failed");
        }
        return null;
    }

}