package com.cucumber.commonServices;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;



public class JavaScriptExecutorService
{


    /** This function is use To get the session token from session local storage  */


    /** This function is use To get the session CompanyId from session local storage  */


    /** This function use To scrollDown WebPage  */
}
