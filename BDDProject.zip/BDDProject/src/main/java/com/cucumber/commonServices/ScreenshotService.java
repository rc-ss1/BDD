package com.cucumber.commonServices;

import com.cucumber.commonBase.Base;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class ScreenshotService extends Base {

    public byte[] takeScreenshots() {


        TakesScreenshot screenshot = (TakesScreenshot) driver;
        byte[] screenshotBytes = screenshot.getScreenshotAs(OutputType.BYTES);
        return screenshotBytes;
    }
}

