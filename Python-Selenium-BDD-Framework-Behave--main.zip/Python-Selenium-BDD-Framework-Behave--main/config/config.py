class TestData:
    BROWSER = 'chrome'
    URL = "https://www.amazon.in/"
    USERNAME = "YourUserName"
    PASSWORD = "qwerty112"

    IMPLICIT_WAIT = 10
