from config.config import TestData
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

from utilities.locators import LoginPage


def before_scenario(context, scenario):
    browser = TestData.BROWSER.lower()

    if browser == 'chrome':
        options = webdriver.ChromeOptions()
        options.add_argument('--start-maximized')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--no-sandbox')
        options.add_argument("--incognito")
        options.add_experimental_option("detach", True)  # Keep browser open

        context.driver = webdriver.Chrome(
            service=ChromeService(ChromeDriverManager().install()),
            options=options

        )

    elif browser == 'firefox':
        context.driver = webdriver.Firefox(
            service=FirefoxService(GeckoDriverManager().install())
        )

    else:
        raise ValueError(f"Browser '{TestData.BROWSER}' is not supported")

    # ✅ Always maximize (Chrome + Firefox)
    context.driver.maximize_window()

    # ✅ Initialize all page objects here
    context.login_page = LoginPage(context.driver)



