import time

import behave
from behave import *
from selenium.webdriver.support.wait import WebDriverWait
from webdriver_manager.core import driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@given("user has just launched the application")
def step_impl(context):
    context.login_page.load_url("https://dev.productselect.skf.com/bearing-housings/index.html#/search/")

    wait = WebDriverWait(context.driver, 10)
    wait.until(EC.element_to_be_clickable((By.XPATH, "//*[contains(text(),'Accept')]"))).click()





@when('he enters "SNL 205" in the "Housing/bearing designation" input field')
def step_impl(context):
    wait = WebDriverWait(context.driver, 30)

    element = wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@placeholder='Input designation']")))
    element.click()
    element.send_keys("SNL 205")


@when('he clicks on "Shaft" button')
def step_impl(context):
    wait = WebDriverWait(context.driver, 20)

    element = wait.until(EC.visibility_of_element_located((By.XPATH, "//h4[@data-comp='heading' and normalize-space()='Shaft']")))
    element.click()




@when('he clicks on "SNL 205" button')
def step_impl(context):
    wait = WebDriverWait(context.driver, 20)
    try:
        wait.until(EC.element_to_be_clickable((By.XPATH, "//button[normalize-space()='SNL 205']"))).click()
    except:
        pass


@when('he clicks on "Bearing" button')
def step_impl(context):
    wait = WebDriverWait(context.driver, 25)
    wait.until(
        EC.element_to_be_clickable((By.XPATH, "//h4[@data-comp='heading' and normalize-space()='Bearing']"))
    ).click()


@then("verify the toggle button displayed")
def step_impl(context):
    text_element = context.driver.find_element(By.XPATH, "//div[normalize-space()='Sealed bearing']")
    toggle_button = context.driver.find_element(By.XPATH, "//div[@id='toggleButton']")

    assert text_element.is_displayed(), "Sealed bearing text is not displayed"
    assert toggle_button.is_displayed(), "Toggle button is not displayed"


@then("verify the text Spherical roller bearing is displayed")
def step_impl(context):
        element = context.driver.find_element(By.XPATH, "//div[normalize-space()='Spherical roller bearing']")
        assert element.is_displayed(), "Element is not displayed"
        assert element.text.strip() == "Spherical roller bearing", "Text does not match"


@when("user lands on Search and Select page")
def step_impl(context):
    wait = WebDriverWait(context.driver, 20)
    wait.until(EC.element_to_be_clickable((By.XPATH, "//*[contains(text(),'Accept')]"))).click()
