import logging
import time

import selenium.common.exceptions

from pages.BasePage import BasePage
from selenium.webdriver.common.by import By


class LoginPage(BasePage):
    TXT_USERNAME = (By.XPATH, "/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")
    BTN_LOGIN = (By.XPATH, "//button[text()=\"Request OTP\"]")
    BTN_VERIFY = (By.XPATH, "//button[text()=\"Verify\"]")
    BTN_CLOSE = (By.XPATH, '//button[text()="✕"]')
    SEARCH_INPUT = (By.XPATH, '//input[contains(@title, "Search for products, brands and more")]')
    FIRST_OPTION = (By.XPATH, '(//form//li//a)[1]')
    SELLER_NAME = (By.XPATH, '((//a[@rel="noopener noreferrer"]/parent::*)[2]//div)[1]')
    PRODUCT_NAME = (By.XPATH, '((//a[@rel="noopener noreferrer"]/parent::*)[2]//a)[1]')
    PRODUCT_PRICE = (By.XPATH, '(((//a[@rel="noopener noreferrer"]/parent::*)[2]//a)[2]/div/div)[1]')

    def __init__(self, driver):
        super().__init__(driver)
